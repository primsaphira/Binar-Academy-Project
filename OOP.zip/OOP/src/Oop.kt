fun main(args: Array<String>) {
    var gameSuit = mutableListOf<String>("Batu", "Gunting", "Kertas")
    var exit = false
    do {
        println("====================================================")
        println("Selamat Datang di Permainan Batu Gunting Kertas ...!")
        println("====================================================")
        println(" Silahkan masukkan pilihan Anda : ")
        println("1. Batu")
        println("2. Gunting")
        println("3. Kertas")
        println("4. Exit")

        print("Masukkan pilihan Pemain 1 : ")

        var input1 = readLine().toString()

        when (input1) {
            "1", "2", "3" -> {
                var exit2 = false
                do {
                    print("Masukkan pilihan Pemain 2 : ")
                    var input2 = readLine().toString()
                    when (input2) {
                        "1", "2", "3" -> {

                            val index1 = input1.toInt().minus(1)
                            val index2 = input2.toInt().minus(1)
                            if (gameSuit[index1] == "Batu" && gameSuit[index2] == "Batu") {
                                println("DRAW !")
                            } else if (gameSuit[index1] == "Batu" && gameSuit[index2] == "Gunting") {
                                println("Pemain 1 Menang ! ")
                            } else if (gameSuit[index1] == "Batu" && gameSuit[index2] == "Kertas") {
                                println("Pemain 2 Menang ! ")
                            } else if (gameSuit[index1] == "Kertas" && gameSuit[index2] == "Kertas") {
                                println("DRAW ! ")
                            } else if (gameSuit[index1] == "Kertas" && gameSuit[index2] == "Batu") {
                                println("Pemain 1 Menang ! ")
                            } else if (gameSuit[index1] == "Kertas" && gameSuit[index2] == "Gunting") {
                                println("Pemain 2 Menang ! ")
                            } else if (gameSuit[index1] == "Gunting" && gameSuit[index2] == "Gunting") {
                                println("DRAW ! ")
                            } else if (gameSuit[index1] == "Gunting" && gameSuit[index2] == "Kertas") {
                                println("Pemain 1 Menang ! ")
                            } else if (gameSuit[index1] == "Gunting" && gameSuit[index2] == "Batu") {
                                println("Pemain 2 Menang ! ")
                            } else {
                                println("Pilihan Salah ! , Masukkan pilihan Anda : '1' , '2' , '3' , atau '4' .. ! ")
                            }
                            exit2 = true
                        }
                        "4" -> {
                            exit2 = true
                        }
                        else -> {
                            println("Pilihan Salah ! , Masukkan pilihan Anda : '1' , '2' , '3' , atau '4' .. !")
                        }
                    }
                } while (!exit2)
            }
            "4" -> {
                exit = true
            }
            else -> {
                println("Pilihan Salah ! , Masukkan pilihan Anda : '1' , '2' , '3' , atau '4' .. !")
            }
        }
    } while (!exit)
}